



#ifndef TILEMAP_TINS2020_HPP
#define TILEMAP_TINS2020_HPP

#include <vector>
#include <string>
#include <map>


class Tile {
public :
   unsigned int tid;
   
};

class Sprite : public AnimationBase {
   virtual void OnSetAnimationPercent() {(void)0;}
   EagleImage*
   
   
};

class Atlas {
   
   std::map<unsigned int , Sprite*>
   
   
public :
   
   
   
};





#endif // TILEMAP_TINS2020_HPP
